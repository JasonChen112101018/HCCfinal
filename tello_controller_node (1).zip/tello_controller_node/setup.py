from setuptools import setup

package_name = 'tello_controller_node'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='you',
    maintainer_email='you@example.com',
    description='Tello controller node',
    license='MIT',
    entry_points={
        'console_scripts': [
            'tello_controller_node_main = tello_controller_node.main:main',
        ],
    },
)
