from setuptools import setup

package_name = 'tello_controller_node'

setup(
    name=package_name,
    version='0.0.0',
    packages=['tello_controller_node'],
    data_files=[
        ('share/' + package_name, ['package.xml']),
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name + '/launch', ['launch/tello_launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='you',
    maintainer_email='you@example.com',
    description='Minimal tello controller node',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'tello_controller_node_main = tello_controller_node.main:main',
        ],
    },
)
